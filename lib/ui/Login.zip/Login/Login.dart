import 'package:apk_lafood/ui/LandingPage/LandingPage.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  final String name = "admin";
  final String pass = "1234";
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _isFormKey = GlobalKey<FormState>();
  bool isLoading = false;

  final userTextBoxController = TextEditingController();
  final passTextBoxController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
          child: Container(
        margin: EdgeInsets.symmetric(vertical: 150.0),
        padding: EdgeInsets.symmetric(horizontal: 8.0),
        alignment: Alignment.center,
        child: Form(
          key: _isFormKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _buildLoginText(),
              _buildLoginWithEmail(),
              _buildLoginWithpass(),
              // button login
              _btnLogin(),
            ],
          ),
        ),
      )),
    );
  }

  Widget _buildLoginText() {
    return Container(
      margin: EdgeInsets.only(bottom: 32.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          // Text login
          Container(
            child: Text(
              "LAFOOD",
              style: TextStyle(
                fontSize: 60.0,
                fontWeight: FontWeight.w500,
                color: Colors.red,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoginWithEmail() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.0),
      child: TextFormField(
        decoration: InputDecoration(labelText: "Username"),
        keyboardType: TextInputType.name,
        controller: userTextBoxController,
        autofocus: true,
        validator: (value) {
          if (value!.isEmpty) {
            return "Username harus di isi..";
          } else if (value == widget.name) {
            return null;
          } else if (value != widget.name) {
            return "Username salah..";
          }
        },
      ),
    );
  }

  Widget _buildLoginWithpass() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.0),
      child: TextFormField(
        decoration: InputDecoration(labelText: "Password"),
        keyboardType: TextInputType.visiblePassword,
        obscureText: true,
        controller: passTextBoxController,
        autofocus: true,
        validator: (value) {
          if (value!.isEmpty) {
            return "Password harus di isi..";
          } else if (value == widget.pass) {
            return null;
          } else if (value != widget.pass) {
            return "password salah..";
          }
          // return null;
        },
      ),
    );
  }

  Widget _btnLogin() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.0),
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              primary: Colors.redAccent,
              textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
          child: Text(
            "Login",
          ),
          onPressed: () {
            var validate = _isFormKey.currentState!.validate();

            if (validate) {
              Navigator.of(context)
                  .pushReplacement(new MaterialPageRoute(builder: (_) {
                return LandingPage();
              }));
            }
          }),
    );
  }
}
